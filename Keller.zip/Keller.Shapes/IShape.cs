﻿namespace Keller
{
    interface IShape
    {
        float Area();
        float Perimeter();
    }
}
